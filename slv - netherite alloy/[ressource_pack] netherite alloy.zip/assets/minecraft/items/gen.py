
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


ids = ["netherite_axe","netherite_boots","netherite_chestplate","netherite_helmet","netherite_hoe","netherite_leggings","netherite_pickaxe","netherite_shovel","netherite_sword","netherite_horse_armor","netherite_nautilus_armor"]

variants = [{"id":"gold","max_damage":1561},{"id":"iron","max_damage":2266}]

for i in ids:
    with open(os.path.join(BASE_DIR,f'{i}.json'),'w') as f:
        f.write(
f'''{{
"model": {{
    "type": "select",
    "fallback": {{
        "type": "model",
        "model": "item/{i}"
    }},
    "property": "component",
    "component": "max_damage",
    "cases": [
        {{
            "when": 1561,
            "model": {{
                "type": "model",
                "model": "item/gold_{i}"
            }}
        }},
        {{
            "when": 2266,
            "model": {{
                "type": "model",
                "model": "item/iron_{i}"
            }}
        }}
    ]
}}
}}
'''
    )
        


