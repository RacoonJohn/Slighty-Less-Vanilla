
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


ids = ["netherite_axe","netherite_boots","netherite_chestplate","netherite_helmet","netherite_hoe","netherite_leggings","netherite_pickaxe","netherite_shovel","netherite_sword","netherite_horse_armor","netherite_nautilus_armor"]

variants = ["gold","iron"]

for v in variants:
    for i in ids:
        with open(os.path.join(BASE_DIR,f'{v}_{i}.json'),'w') as f:
            f.write(
    f'''{{
    "parent": "item/handheld",
    "textures": {{
        "layer0":"item/{v}_{i}"
    }}
}}
'''
    )
        


